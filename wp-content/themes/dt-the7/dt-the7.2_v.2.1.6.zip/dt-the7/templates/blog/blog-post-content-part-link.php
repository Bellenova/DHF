<?php
/**
 * Blog link post format content part
 *
 * @package vogue
 * @since 1.0.0
 */

// File Security Check
if ( ! defined( 'ABSPATH' ) ) { exit; }

?>
		<div class="format-link-content">
			<?php the_content(); ?>
		</div>